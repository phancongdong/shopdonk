const db = require('../utils/database');
const config = require('../config');

module.exports = {
    async stats(bot, msg) {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();
        
        if (!config.isAdmin(userId)) {
            return bot.sendMessage(chatId, '❌ Bạn không có quyền admin!');
        }
        
        const stats = db.getStats();
        
        let message = `📊 *THỐNG KÊ SHOP*\n`;
        message += `━━━━━━━━━━━━━━━━━━━━\n\n`;
        message += `💰 *Doanh thu:*\n`;
        message += `   Tổng: ${stats.totalRevenue.toLocaleString()}đ\n`;
        message += `   Hôm nay: ${stats.todayRevenue.toLocaleString()}đ\n`;
        message += `   Refunds: ${stats.totalRefunds?.toLocaleString() || 0}đ\n\n`;
        
        message += `📦 *Đơn hàng:*\n`;
        message += `   Tổng: ${stats.totalOrders}\n`;
        message += `   Hôm nay: ${stats.todayOrders}\n\n`;
        
        message += `🎮 *Sản phẩm:*\n`;
        message += `   Tổng: ${stats.totalProducts}\n`;
        message += `   Có hàng: ${stats.inStockProducts}\n\n`;
        
        message += `👥 *Users:*\n`;
        message += `   Tổng: ${stats.totalUsers}\n\n`;
        
        message += `💳 *Nạp:*\n`;
        message += `   Tổng nạp: ${stats.totalDeposits?.toLocaleString() || 0}đ\n`;
        message += `   Chờ duyệt: ${stats.pendingDeposits}\n\n`;
        
        message += `📁 *Categories:* ${stats.totalCategories}`;
        
        await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    },

    async users(bot, msg) {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();
        
        if (!config.isAdmin(userId)) {
            return bot.sendMessage(chatId, '❌ Bạn không có quyền admin!');
        }
        
        const users = Object.values(db.data.users);
        
        if (users.length === 0) {
            return bot.sendMessage(chatId, '📭 Không có user nào!');
        }
        
        let message = `👥 *Danh sách users (${users.length})*\n`;
        message += `━━━━━━━━━━━━━━━━━━━━\n\n`;
        
        users.slice(0, 30).forEach(u => {
            const roleIcon = u.role === 'admin' ? '👑' : u.role === 'ctv' ? '🔧' : '👤';
            message += `${roleIcon} ${u.name || 'No name'}\n`;
            message += `   🆔 ${u.id}\n`;
            message += `   💰 ${u.balance?.toLocaleString() || 0}đ\n`;
            message += `   📦 ${u.orders?.length || 0} orders\n`;
            message += `   📅 ${new Date(u.createdAt).toLocaleDateString('vi-VN')}\n\n`;
        });
        
        if (users.length > 30) {
            message += `\n_... và ${users.length - 30} users khác_`;
        }
        
        message += `\n💡 /user [id] - Chi tiết user`;
        
        await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    },

    async user(bot, msg, match) {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();
        const targetUserId = match[1];
        
        if (!config.isAdmin(userId)) {
            return bot.sendMessage(chatId, '❌ Bạn không có quyền admin!');
        }
        
        const user = db.getUser(targetUserId);
        const orders = db.getOrdersByUser(targetUserId, 10);
        const transactions = db.getTransactions(targetUserId, 5);
        
        let message = `👤 *USER ${targetUserId}*\n`;
        message += `━━━━━━━━━━━━━━━━━━━━\n`;
        message += `🆔 ID: ${targetUserId}\n`;
        message += `👤 Name: ${user.name || 'Chưa đặt'}\n`;
        message += `💰 Balance: ${user.balance?.toLocaleString() || 0}đ\n`;
        message += `🎭 Role: ${user.role || 'user'}\n`;
        message += `📦 Orders: ${user.orders?.length || 0}\n`;
        message += `━━━━━━━━━━━━━━━━━━━━\n\n`;
        
        if (orders.length > 0) {
            message += `📋 *Orders gần đây:*\n`;
            orders.slice(0, 5).forEach(o => {
                message += `   📦 ${o.productName} - ${o.total_price.toLocaleString()}đ\n`;
            });
            message += `\n`;
        }
        
        if (transactions.length > 0) {
            message += `💳 *GD gần đây:*\n`;
            transactions.slice(0, 3).forEach(t => {
                message += `   ${t.amount >= 0 ? '+' : ''}${t.amount.toLocaleString()}đ - ${t.type}\n`;
            });
        }
        
        const keyboard = {
            inline_keyboard: [
                [
                    { text: '💰 Cộng tiền', callback_data: `addmoney_${targetUserId}` },
                    { text: '💸 Trừ tiền', callback_data: `deduct_${targetUserId}` }
                ],
                [
                    { text: '📋 Orders', callback_data: `userorders_${targetUserId}` },
                    { text: '💳 Transactions', callback_data: `usertrans_${targetUserId}` }
                ]
            ]
        };
        
        await bot.sendMessage(chatId, message, {
            parse_mode: 'Markdown',
            reply_markup: keyboard
        });
    },

    async addMoney(bot, msg, match) {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();
        
        if (!config.isAdmin(userId)) {
            return bot.sendMessage(chatId, '❌ Bạn không có quyền admin!');
        }
        
        const parts = match[1].split(' ');
        const targetUserId = parts[0];
        const amount = parseInt(parts[1]);
        const note = parts.slice(2).join(' ') || 'Admin cộng tiền';
        
        if (!amount || amount <= 0) {
            return bot.sendMessage(chatId, 
                '❌ Số tiền không hợp lệ!\n' +
                '/addmoney [user_id] [amount] [note]');
        }
        
        const user = db.getUser(targetUserId);
        user.balance += amount;
        
        await db.createTransaction(targetUserId, 'admin_add', amount, note);
        await db.save();
        
        await bot.sendMessage(chatId,
            `✅ *Đã cộng tiền!*\n\n` +
            `👤 User: ${targetUserId}\n` +
            `💵 +${amount.toLocaleString()}đ\n` +
            `📝 ${note}\n` +
            `💰 New balance: ${user.balance.toLocaleString()}đ`,
            { parse_mode: 'Markdown' }
        );
        
        try {
            await bot.sendMessage(targetUserId,
                `💰 *Bạn đã nhận được tiền!*\n\n` +
                `💵 +${amount.toLocaleString()}đ\n` +
                `📝 ${note}\n` +
                `💰 Balance: ${user.balance.toLocaleString()}đ`
            );
        } catch (e) {}
    },

    async deductMoney(bot, msg, match) {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();
        
        if (!config.isAdmin(userId)) {
            return bot.sendMessage(chatId, '❌ Bạn không có quyền admin!');
        }
        
        const parts = match[1].split(' ');
        const targetUserId = parts[0];
        const amount = parseInt(parts[1]);
        const note = parts.slice(2).join(' ') || 'Admin trừ tiền';
        
        if (!amount || amount <= 0) {
            return bot.sendMessage(chatId, 
                '❌ Số tiền không hợp lệ!\n' +
                '/deductmoney [user_id] [amount] [note]');
        }
        
        const user = db.getUser(targetUserId);
        
        if (user.balance < amount) {
            return bot.sendMessage(chatId,
                `❌ User không đủ tiền!\n` +
                `💰 Balance: ${user.balance.toLocaleString()}đ\n` +
                `💸 Muốn trừ: ${amount.toLocaleString()}đ`
            );
        }
        
        user.balance -= amount;
        
        await db.createTransaction(targetUserId, 'admin_deduct', -amount, note);
        await db.save();
        
        await bot.sendMessage(chatId,
            `✅ *Đã trừ tiền!*\n\n` +
            `👤 User: ${targetUserId}\n` +
            `💸 -${amount.toLocaleString()}đ\n` +
            `📝 ${note}\n` +
            `💰 New balance: ${user.balance.toLocaleString()}đ`,
            { parse_mode: 'Markdown' }
        );
        
        try {
            await bot.sendMessage(targetUserId,
                `💸 *Tài khoản bị trừ tiền!*\n\n` +
                `💸 -${amount.toLocaleString()}đ\n` +
                `📝 ${note}\n` +
                `💰 Balance: ${user.balance.toLocaleString()}đ`
            );
        } catch (e) {}
    },

    async transactions(bot, msg, match) {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();
        
        if (!config.isAdmin(userId)) {
            return bot.sendMessage(chatId, '❌ Bạn không có quyền admin!');
        }
        
        const targetUserId = match && match[1] ? match[1] : null;
        
        const transactions = targetUserId 
            ? db.getTransactions(targetUserId, 30)
            : db.getAllTransactions(50);
        
        if (transactions.length === 0) {
            return bot.sendMessage(chatId, '📭 Không có giao dịch nào!');
        }
        
        let message = `💳 *Lịch sử giao dịch*\n`;
        message += targetUserId ? `User: ${targetUserId}\n` : '(Tất cả)\n';
        message += `━━━━━━━━━━━━━━━━━━━━\n\n`;
        
        transactions.slice(0, 30).forEach(t => {
            const date = new Date(t.createdAt).toLocaleDateString('vi-VN');
            const icon = t.amount >= 0 ? '💰' : '💸';
            
            message += `${icon} ${t.type.toUpperCase()}\n`;
            message += `   ${t.amount >= 0 ? '+' : ''}${t.amount.toLocaleString()}đ\n`;
            message += `   User: ${t.userId}\n`;
            message += `   📝 ${t.description}\n`;
            message += `   📅 ${date}\n\n`;
        });
        
        await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    },

    async orders(bot, msg, match) {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();
        
        if (!config.isAdmin(userId)) {
            return bot.sendMessage(chatId, '❌ Bạn không có quyền admin!');
        }
        
        const status = match && match[1] ? match[1] : null;
        const filters = status ? { status } : { limit: 50 };
        
        const orders = db.getAllOrders(filters);
        
        if (orders.length === 0) {
            return bot.sendMessage(chatId, '📭 Không có đơn hàng nào!');
        }
        
        let message = `📦 *Danh sách orders (${orders.length})*\n`;
        message += status ? `Filter: ${status}\n` : '';
        message += `━━━━━━━━━━━━━━━━━━━━\n\n`;
        
        orders.slice(0, 30).forEach(o => {
            const date = new Date(o.createdAt).toLocaleDateString('vi-VN');
            const icon = o.status === 'completed' ? '✅' : 
                        o.status === 'refunded' ? '💸' : '⏳';
            
            message += `${icon} #${o.id}\n`;
            message += `   📦 ${o.productName}\n`;
            message += `   👤 ${o.userId}\n`;
            message += `   💰 ${o.total_price.toLocaleString()}đ | ${o.quantity} nick\n`;
            message += `   📅 ${date}\n\n`;
        });
        
        message += `\n💡 /order [id] - Chi tiết`;
        
        await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    },

    async order(bot, msg, match) {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();
        const orderId = match[1];
        
        if (!config.isAdmin(userId)) {
            return bot.sendMessage(chatId, '❌ Bạn không có quyền admin!');
        }
        
        const order = db.getOrderById(orderId);
        
        if (!order) {
            return bot.sendMessage(chatId, '❌ Order không tồn tại!');
        }
        
        let message = `📦 *ORDER #${orderId}*\n`;
        message += `━━━━━━━━━━━━━━━━━━━━\n`;
        message += `👤 User: ${order.userId}\n`;
        message += `📦 Product: ${order.productName}\n`;
        message += `🔢 Qty: ${order.quantity}\n`;
        message += `💰 Total: ${order.total_price.toLocaleString()}đ\n`;
        message += `🎭 Status: ${order.status}\n`;
        message += `📅 Date: ${new Date(order.createdAt).toLocaleString('vi-VN')}\n`;
        message += `━━━━━━━━━━━━━━━━━━━━\n\n`;
        
        if (order.accounts && order.accounts.length > 0) {
            message += `🔐 *Accounts:*\n`;
            order.accounts.forEach((acc, idx) => {
                message += `${idx + 1}. ${acc.username} - ${acc.password}\n`;
            });
        }
        
        const keyboard = {
            inline_keyboard: []
        };
        
        if (order.status === 'completed') {
            keyboard.inline_keyboard.push([
                { text: '💸 Refund', callback_data: `refund_${orderId}` }
            ]);
        }
        
        keyboard.inline_keyboard.push([
            { text: '👤 Xem User', callback_data: `user_${order.userId}` }
        ]);
        
        await bot.sendMessage(chatId, message, {
            parse_mode: 'Markdown',
            reply_markup: keyboard
        });
    },

    async refund(bot, msg, match) {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();
        const orderId = match[1];
        
        if (!config.isAdmin(userId)) {
            return bot.sendMessage(chatId, '❌ Bạn không có quyền admin!');
        }
        
        try {
            const order = await db.refundOrder(orderId);
            
            await bot.sendMessage(chatId,
                `✅ *Hoàn tiền thành công!*\n\n` +
                `📦 Order: #${orderId}\n` +
                `👤 User: ${order.userId}\n` +
                `💸 Refund: ${order.total_price.toLocaleString()}đ\n` +
                `🎭 Status: refunded`
            );
            
            try {
                const user = db.getUser(order.userId);
                await bot.sendMessage(order.userId,
                    `💸 *Đơn hàng đã được hoàn tiền!*\n\n` +
                    `📦 #${orderId} - ${order.productName}\n` +
                    `💰 +${order.total_price.toLocaleString()}đ\n` +
                    `💵 Balance: ${user.balance.toLocaleString()}đ`
                );
            } catch (e) {}
            
        } catch (error) {
            await bot.sendMessage(chatId, `❌ ${error.message}`);
        }
    },

    async products(bot, msg) {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();
        
        if (!config.isAdmin(userId)) {
            return bot.sendMessage(chatId, '❌ Bạn không có quyền admin!');
        }
        
        const products = db.getAllProducts(true);
        
        if (products.length === 0) {
            return bot.sendMessage(chatId, '📭 Không có sản phẩm!');
        }
        
        let message = `📦 *Danh sách products (${products.length})*\n`;
        message += `━━━━━━━━━━━━━━━━━━━━\n\n`;
        
        products.slice(0, 30).forEach(p => {
            const statusIcon = p.is_hidden ? '🙈' : p.stock > 0 ? '✅' : '❌';
            const featuredIcon = p.featured ? '⭐' : '';
            
            message += `${statusIcon}${featuredIcon} *${p.name}*\n`;
            message += `   💰 ${p.price.toLocaleString()}đ`;
            if (p.cost_price) message += ` (vốn: ${p.cost_price.toLocaleString()}đ)`;
            message += `\n   📦 ${p.stock} acc | ${p.category}\n`;
            message += `   🆔 \`${p.id}\`\n\n`;
        });
        
        if (products.length > 30) {
            message += `\n_... và ${products.length - 30} khác_`;
        }
        
        message += `\n💡 /product [id] - Chi tiết\n`;
        message += `💡 /add - Thêm sản phẩm`;
        
        await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    },

    async add(bot, msg) {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();
        
        if (!config.isAdmin(userId)) {
            return bot.sendMessage(chatId, '❌ Bạn không có quyền admin!');
        }
        
        await bot.sendMessage(chatId, 
            '📦 *THÊM SẢN PHẨM MỚI*\n\n' +
            'Gửi thông tin theo format:\n\n' +
            '```\n' +
            'NAME: Tên sản phẩm\n' +
            'CATEGORY: genshin (hoặc lol, valorant, pubg, freefire, other)\n' +
            'PRICE: 100000\n' +
            'COST: 50000 (giá vốn, optional)\n' +
            'DESC: Mô tả (optional)\n' +
            'FEATURED: yes/no (optional)\n' +
            'ACCOUNTS:\n' +
            'email1@gmail.com-password123-extra1\n' +
            'email2@gmail.com-password456-extra2\n' +
            '```',
            { parse_mode: 'Markdown' }
        );
        
        bot.once('message', async (response) => {
            if (response.from.id.toString() !== userId) return;
            
            try {
                const text = response.text;
                const name = text.match(/NAME:\s*(.+)/i)?.[1]?.trim();
                const category = text.match(/CATEGORY:\s*(.+)/i)?.[1]?.trim()?.toLowerCase();
                const price = parseInt(text.match(/PRICE:\s*(\d+)/i)?.[1]);
                const costPrice = parseInt(text.match(/COST:\s*(\d+)/i)?.[1]) || 0;
                const desc = text.match(/DESC:\s*(.+)/i)?.[1]?.trim();
                const featured = text.match(/FEATURED:\s*(yes|true|1)/i)?.[1] ? true : false;
                const accountsText = text.split('ACCOUNTS:')[1];
                
                if (!name || !price) {
                    return bot.sendMessage(chatId, '❌ Thiếu NAME hoặc PRICE!');
                }
                
                const accounts = accountsText
                    ? accountsText.split('\n')
                        .filter(line => line.trim() && line.includes('-'))
                        .map(line => {
                            const parts = line.trim().split('-');
                            return {
                                username: parts[0]?.trim(),
                                password: parts[1]?.trim(),
                                extra: parts[2]?.trim() || null
                            };
                        })
                    : [];
                
                const product = await db.addProduct({
                    name,
                    category: category || 'other',
                    price,
                    cost_price: costPrice,
                    description: desc || '',
                    featured,
                    accounts,
                    account_type: 'multiple',
                    image: null
                });
                
                await bot.sendMessage(chatId, 
                    `✅ *Đã thêm sản phẩm!*\n\n` +
                    `📦 ${product.name}\n` +
                    `💰 ${product.price.toLocaleString()}đ\n` +
                    `📦 Stock: ${product.stock} acc\n` +
                    `🆔 \`${product.id}\``,
                    { parse_mode: 'Markdown' }
                );
                
            } catch (error) {
                await bot.sendMessage(chatId, `❌ Lỗi: ${error.message}`);
            }
        });
    },

    async edit(bot, msg, match) {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();
        const productId = match[1];
        
        if (!config.isAdmin(userId)) {
            return bot.sendMessage(chatId, '❌ Bạn không có quyền admin!');
        }
        
        const product = db.getProduct(productId);
        if (!product) {
            return bot.sendMessage(chatId, '❌ Sản phẩm không tồn tại!');
        }
        
        await bot.sendMessage(chatId, 
            `📝 *SỬA SẢN PHẨM #${productId}*\n\n` +
            `Current: ${product.name}\n` +
            `Price: ${product.price.toLocaleString()}đ\n` +
            `Stock: ${product.stock}\n\n` +
            'Gửi thông tin cần cập nhật:\n\n' +
            '```\n' +
            'NAME: Tên mới (optional)\n' +
            'PRICE: Giá mới (optional)\n' +
            'DESC: Mô tả mới (optional)\n' +
            'COST: Giá vốn (optional)\n' +
            'FEATURED: yes/no (optional)\n' +
            'HIDDEN: yes/no (optional)\n' +
            'ACCOUNTS:\n' +
            'new@email.com-pass123 (thêm acc mới)\n' +
            '```',
            { parse_mode: 'Markdown' }
        );
        
        bot.once('message', async (response) => {
            if (response.from.id.toString() !== userId) return;
            
            const text = response.text;
            const updates = {};
            
            const name = text.match(/NAME:\s*(.+)/i)?.[1]?.trim();
            const price = text.match(/PRICE:\s*(\d+)/i)?.[1];
            const cost = text.match(/COST:\s*(\d+)/i)?.[1];
            const desc = text.match(/DESC:\s*(.+)/i)?.[1]?.trim();
            const featured = text.match(/FEATURED:\s*(.+)/i)?.[1]?.trim();
            const hidden = text.match(/HIDDEN:\s*(yes|true|1)/i)?.[1];
            const accountsText = text.split('ACCOUNTS:')[1];
            
            if (name) updates.name = name;
            if (price) updates.price = parseInt(price);
            if (cost) updates.cost_price = parseInt(cost);
            if (desc) updates.description = desc;
            if (featured) updates.featured = featured.toLowerCase() === 'yes';
            if (hidden) updates.is_hidden = true;
            
            if (accountsText) {
                const newAccounts = accountsText
                    .split('\n')
                    .filter(line => line.trim() && line.includes('-'))
                    .map(line => {
                        const parts = line.trim().split('-');
                        return {
                            username: parts[0]?.trim(),
                            password: parts[1]?.trim(),
                            extra: parts[2]?.trim() || null
                        };
                    });
                
                updates.accounts = [...(product.accounts || []), ...newAccounts];
            }
            
            await db.updateProduct(productId, updates);
            const updated = db.getProduct(productId);
            
            await bot.sendMessage(chatId,
                `✅ *Đã cập nhật!*\n\n` +
                `📦 ${updated.name}\n` +
                `💰 ${updated.price.toLocaleString()}đ\n` +
                `📦 Stock: ${updated.stock} acc`
            );
        });
    },

    async delete(bot, msg, match) {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();
        const productId = match[1];
        
        if (!config.isAdmin(userId)) {
            return bot.sendMessage(chatId, '❌ Bạn không có quyền admin!');
        }
        
        const product = db.getProduct(productId);
        if (!product) {
            return bot.sendMessage(chatId, '❌ Sản phẩm không tồn tại!');
        }
        
        const keyboard = {
            inline_keyboard: [
                [
                    { text: '✅ Xóa', callback_data: `confirm_delete_${productId}` },
                    { text: '❌ Hủy', callback_data: 'cancel' }
                ]
            ]
        };
        
        await bot.sendMessage(chatId,
            `⚠️ *XÁC NHẬN XÓA*\n\n` +
            `📦 ${product.name}\n` +
            `💰 ${product.price.toLocaleString()}đ\n` +
            `📦 Stock: ${product.stock}\n` +
            `🆔 ${productId}`,
            { parse_mode: 'Markdown', reply_markup: keyboard }
        );
    },

    async deposits(bot, msg) {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();
        
        if (!config.isAdmin(userId)) {
            return bot.sendMessage(chatId, '❌ Bạn không có quyền admin!');
        }
        
        const pending = db.getPendingDeposits();
        
        if (pending.length === 0) {
            return bot.sendMessage(chatId, '✅ Không có yêu cầu nạp chờ duyệt!');
        }
        
        let message = `📥 *Yêu cầu nạp tiền (${pending.length})*\n`;
        message += `━━━━━━━━━━━━━━━━━━━━\n\n`;
        
        pending.forEach(d => {
            const date = new Date(d.createdAt).toLocaleString('vi-VN');
            message += `💵 ${d.amount.toLocaleString()}đ\n`;
            message += `   👤 ${d.userId}\n`;
            message += `   📱 ${d.method}\n`;
            message += `   📅 ${date}\n`;
            message += `   🆔 \`${d.id}\`\n\n`;
        });
        
        message += `\n💡 /approve [id] - Duyệt\n`;
        message += `💡 /reject [id] - Từ chối`;
        
        await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    },

    async approve(bot, msg, match) {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();
        const depositId = match[1];
        
        if (!config.isAdmin(userId)) {
            return bot.sendMessage(chatId, '❌ Bạn không có quyền admin!');
        }
        
        const deposit = await db.approveDeposit(depositId);
        
        if (!deposit) {
            return bot.sendMessage(chatId, '❌ Không tìm thấy hoặc đã duyệt!');
        }
        
        await bot.sendMessage(chatId,
            `✅ *Đã duyệt nạp tiền!*\n\n` +
            `👤 User: ${deposit.userId}\n` +
            `💵 +${deposit.amount.toLocaleString()}đ\n` +
            `🆔 Deposit: ${depositId}`
        );
        
        try {
            const user = db.getUser(deposit.userId);
            await bot.sendMessage(deposit.userId,
                `✅ *Nạp tiền thành công!*\n\n` +
                `💵 +${deposit.amount.toLocaleString()}đ\n` +
                `💰 Balance: ${user.balance.toLocaleString()}đ`
            );
        } catch (e) {}
    },

    async reject(bot, msg, match) {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();
        const depositId = match[1];
        
        if (!config.isAdmin(userId)) {
            return bot.sendMessage(chatId, '❌ Bạn không có quyền admin!');
        }
        
        const deposit = await db.rejectDeposit(depositId);
        
        if (!deposit) {
            return bot.sendMessage(chatId, '❌ Không tìm thấy hoặc đã xử lý!');
        }
        
        await bot.sendMessage(chatId,
            `❌ *Đã từ chối nạp!*\n\n` +
            `👤 User: ${deposit.userId}\n` +
            `💵 ${deposit.amount.toLocaleString()}đ`
        );
        
        try {
            await bot.sendMessage(deposit.userId,
                `❌ *Yêu cầu nạp bị từ chối!*\n\n` +
                `💵 ${deposit.amount.toLocaleString()}đ\n` +
                `📝 Vui lòng liên hệ admin.`
            );
        } catch (e) {}
    },

    async broadcast(bot, msg, match) {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();
        const messageText = match[1];
        
        if (!config.isAdmin(userId)) {
            return bot.sendMessage(chatId, '❌ Bạn không có quyền admin!');
        }
        
        const users = Object.keys(db.data.users);
        let success = 0;
        let failed = 0;
        
        await bot.sendMessage(chatId, `📢 Đang gửi đến ${users.length} users...`);
        
        for (const uid of users) {
            try {
                await bot.sendMessage(uid,
                    `📢 *Thông báo*\n\n${messageText}`,
                    { parse_mode: 'Markdown' }
                );
                success++;
            } catch (e) {
                failed++;
            }
        }
        
        await bot.sendMessage(chatId,
            `✅ *Broadcast hoàn tất!*\n\n` +
            `✅ Thành công: ${success}\n` +
            `❌ Thất bại: ${failed}`
        );
    },

    async export(bot, msg, match) {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();
        const type = match[1]?.toLowerCase();
        
        if (!config.isAdmin(userId)) {
            return bot.sendMessage(chatId, '❌ Bạn không có quyền admin!');
        }
        
        if (type === 'orders') {
            const orders = db.exportOrders({ limit: 100 });
            let message = `📦 *Export Orders (${orders.length})*\n`;
            message += `━━━━━━━━━━━━━━━━━━━━\n\n`;
            
            orders.slice(0, 20).forEach(o => {
                message += `#${o.id} | ${o.user_id} | ${o.product} | ${o.total}đ | ${o.status}\n`;
            });
            
            await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
            
        } else if (type === 'products') {
            const products = db.exportProducts(true);
            let message = `📦 *Export Products (${products.length})*\n`;
            message += `━━━━━━━━━━━━━━━━━━━━\n\n`;
            
            products.slice(0, 20).forEach(p => {
                message += `${p.id} | ${p.name} | ${p.price}đ | ${p.stock} | ${p.category}\n`;
            });
            
            await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
            
        } else {
            await bot.sendMessage(chatId,
                '📦 *Export*\n\n' +
                '/export orders\n' +
                '/export products'
            );
        }
    },

    async handleApproveCallback(bot, query, depositId) {
        const userId = query.from.id.toString();
        if (!config.isAdmin(userId)) return;
        
        const deposit = await db.approveDeposit(depositId);
        
        if (!deposit) {
            return bot.editMessageCaption('❌ Lỗi duyệt!', {
                chat_id: query.message.chat.id,
                message_id: query.message.message_id
            });
        }
        
        await bot.editMessageCaption(
            `✅ *ĐÃ DUYỆT*\n\n` +
            `👤 User: ${deposit.userId}\n` +
            `💵 +${deposit.amount.toLocaleString()}đ\n` +
            `👨‍💼 By: ${query.from.first_name}`,
            {
                chat_id: query.message.chat.id,
                message_id: query.message.message_id,
                parse_mode: 'Markdown'
            }
        );
        
        try {
            const user = db.getUser(deposit.userId);
            await bot.sendMessage(deposit.userId,
                `✅ *Nạp tiền thành công!*\n\n` +
                `💵 +${deposit.amount.toLocaleString()}đ\n` +
                `💰 Balance: ${user.balance.toLocaleString()}đ`
            );
        } catch (e) {}
    },

    async handleRejectCallback(bot, query, depositId) {
        const userId = query.from.id.toString();
        if (!config.isAdmin(userId)) return;
        
        const deposit = await db.rejectDeposit(depositId);
        
        await bot.editMessageCaption(
            `❌ *ĐÃ TỪ CHỐI*\n\n` +
            `👤 User: ${deposit?.userId}\n` +
            `💵 ${deposit?.amount?.toLocaleString()}đ`,
            {
                chat_id: query.message.chat.id,
                message_id: query.message.message_id,
                parse_mode: 'Markdown'
            }
        );
        
        if (deposit) {
            try {
                await bot.sendMessage(deposit.userId,
                    `❌ *Yêu cầu nạp bị từ chối!*\n\n` +
                    `💵 ${deposit.amount.toLocaleString()}đ`
                );
            } catch (e) {}
        }
    },

    async handleRefundCallback(bot, query, orderId) {
        const userId = query.from.id.toString();
        if (!config.isAdmin(userId)) return;
        
        try {
            const order = await db.refundOrder(orderId);
            
            await bot.editMessageText(
                `✅ *ĐÃ HOÀN TIỀN*\n\n` +
                `📦 #${orderId}\n` +
                `👤 ${order.userId}\n` +
                `💸 ${order.total_price.toLocaleString()}đ`,
                {
                    chat_id: query.message.chat.id,
                    message_id: query.message.message_id,
                    parse_mode: 'Markdown'
                }
            );
            
            try {
                const user = db.getUser(order.userId);
                await bot.sendMessage(order.userId,
                    `💸 *Đơn hàng hoàn tiền!*\n\n` +
                    `📦 #${orderId}\n` +
                    `💰 +${order.total_price.toLocaleString()}đ\n` +
                    `💵 Balance: ${user.balance.toLocaleString()}đ`
                );
            } catch (e) {}
            
        } catch (error) {
            await bot.answerCallbackQuery(query.id, { text: error.message, show_alert: true });
        }
    },

    async handleDeleteCallback(bot, query, productId) {
        const userId = query.from.id.toString();
        if (!config.isAdmin(userId)) return;
        
        const deleted = await db.deleteProduct(productId);
        
        if (deleted) {
            await bot.editMessageText(
                `✅ *Đã xóa sản phẩm!*\n\n🆔 ${productId}`,
                {
                    chat_id: query.message.chat.id,
                    message_id: query.message.message_id,
                    parse_mode: 'Markdown'
                }
            );
        } else {
            await bot.answerCallbackQuery(query.id, { text: 'Lỗi xóa!', show_alert: true });
        }
    },

    async handleAddMoneyCallback(bot, query, targetUserId) {
        const userId = query.from.id.toString();
        if (!config.isAdmin(userId)) return;
        
        await bot.sendMessage(query.message.chat.id,
            `💰 *Cộng tiền cho ${targetUserId}*\n\n` +
            `Gửi: /addmoney ${targetUserId} [amount] [note]\n` +
            `Ví dụ: /addmoney ${targetUserId} 50000 Bonus`
        );
    },

    async handleDeductMoneyCallback(bot, query, targetUserId) {
        const userId = query.from.id.toString();
        if (!config.isAdmin(userId)) return;
        
        await bot.sendMessage(query.message.chat.id,
            `💸 *Trừ tiền của ${targetUserId}*\n\n` +
            `Gửi: /deductmoney ${targetUserId} [amount] [note]\n` +
            `Ví dụ: /deductmoney ${targetUserId} 10000 Penalty`
        );
    },

    async handleUserOrdersCallback(bot, query, targetUserId) {
        const userId = query.from.id.toString();
        if (!config.isAdmin(userId)) return;
        
        const orders = db.getOrdersByUser(targetUserId, 10);
        
        if (orders.length === 0) {
            return bot.sendMessage(query.message.chat.id, '📭 User này chưa mua hàng!');
        }
        
        let message = `📦 *Orders của ${targetUserId}*\n\n`;
        orders.forEach(o => {
            message += `#${o.id} | ${o.productName} | ${o.total_price.toLocaleString()}đ\n`;
        });
        
        await bot.sendMessage(query.message.chat.id, message);
    },

    async handleUserTransactionsCallback(bot, query, targetUserId) {
        const userId = query.from.id.toString();
        if (!config.isAdmin(userId)) return;
        
        const transactions = db.getTransactions(targetUserId, 20);
        
        if (transactions.length === 0) {
            return bot.sendMessage(query.message.chat.id, '📭 User này chưa có GD!');
        }
        
        let message = `💳 *GD của ${targetUserId}*\n\n`;
        transactions.forEach(t => {
            message += `${t.type} | ${t.amount >= 0 ? '+' : ''}${t.amount.toLocaleString()}đ | ${t.description}\n`;
        });
        
        await bot.sendMessage(query.message.chat.id, message);
    },

    async handleCallback(bot, query) {
        const data = query.data;
        
        if (data.startsWith('approve_')) {
            const depositId = data.replace('approve_', '');
            await this.handleApproveCallback(bot, query, depositId);
        } else if (data.startsWith('reject_')) {
            const depositId = data.replace('reject_', '');
            await this.handleRejectCallback(bot, query, depositId);
        } else if (data.startsWith('refund_')) {
            const orderId = data.replace('refund_', '');
            await this.handleRefundCallback(bot, query, orderId);
        } else if (data.startsWith('confirm_delete_')) {
            const productId = data.replace('confirm_delete_', '');
            await this.handleDeleteCallback(bot, query, productId);
        } else if (data.startsWith('addmoney_')) {
            const targetUserId = data.replace('addmoney_', '');
            await this.handleAddMoneyCallback(bot, query, targetUserId);
        } else if (data.startsWith('deduct_')) {
            const targetUserId = data.replace('deduct_', '');
            await this.handleDeductMoneyCallback(bot, query, targetUserId);
        } else if (data.startsWith('userorders_')) {
            const targetUserId = data.replace('userorders_', '');
            await this.handleUserOrdersCallback(bot, query, targetUserId);
        } else if (data.startsWith('usertrans_')) {
            const targetUserId = data.replace('usertrans_', '');
            await this.handleUserTransactionsCallback(bot, query, targetUserId);
        } else if (data.startsWith('user_')) {
            const targetUserId = data.replace('user_', '');
            await this.user(bot, query.message, [null, targetUserId]);
        } else if (data === 'cancel') {
            await bot.deleteMessage(query.message.chat.id, query.message.message_id);
        }
        
        bot.answerCallbackQuery(query.id);
    }
};